<html>
	<head>
		<link rel="stylesheet" href="style.css"/>
		<link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/font-awesome.css">
		<meta charset="utf-8"/>
	</head>
	<body> 
		
		<div id="loginform">
		   <i class="fa fa-times" aria-hidden="true"></i>  
		 
      <form action="login.php" method="post">
            <input name="username" type="text" placeholder="username"><br>
            <input name="password" type="password" placeholder="password"><br>
            <input name="submit" type="submit" id="ss" >
        </form>
			
			
		   
      </div>
		
		<!--header-->
		<div id="header">
        <div id="overlay">
            <div id="nav">
              <div class="container" >
                <ul>
                  <li><a href="index.php#department"><i class="fa fa-bars" aria-hidden="true"></i> department</a></li>
                  <li><a href="Pharmacy.php">pharmacy</a></li>
                  <li><a href="reserve.php">reserve</a></li>
                  <li><a href="reges.php">register</a></li>
                  <li id="loginf"><a href="#">login</a></li>
                </ul>
              </div>
              <div id="search">
                <form action="">
                  <input type="search" name="" value="" placeholder="Search">
                  <i class="fa fa-search" aria-hidden="true"></i>
                </form>
              </div>
				<a href="index.php"><img src="image/logo.png" alt=""></a>
			</div>
			</div>
		</div>
		

		<div id="container">
			<form action="Pharmacy.php" method="post" id="please">
			<input type="hidden" name="start">
			<input type="submit" value="please click here to get start shoping">
		
		</form>
			<div id="content">
				<h1>Top products</h1>
				<div class="products">
					<form action="Pharmacy.php" method="get">
					<img src="Pharamcy image/1.jpg"/>

					<p>
						Paracetamol Caplets
					</p>
					<div class="cmore">
					<input type="hidden" name="ParacetamolCaplets" value="ParacetamolCaplets">
					<button type="submit">&#43; Add to shop car</button>
						
					</div>
						</form>
				</div>
				<div class="products">
					<form action="Pharmacy.php" method="get">
					<img src="Pharamcy image/2.jpg"/>

					<p>
						STRONG Expectorant cough
					</p>
					<div class="cmore">
						
						<input type="hidden"  name="STRONGExpectorantcough" value="STRONGExpectorantcough">
				<button type="submit">&#43; Add to shop car</button>
					</div>
					</form>
				</div>
				<div class="products">
					<img src="Pharamcy image/3.jpg"/>

					<p>
						D 2
					</p>
					<div class="cmore">
						<input name="D2" type="hidden" value="D2">
					<button  type="submit">&#43; Add to shop car</button>
					</div>
				</div>
				<div class="products">
				<form action="Pharmacy.php" method="get">
					<img src="Pharamcy image/4.jpg"/>
				

					<p>
						Tim & TAMMYS
					</p>
					<div class="cmore">
						<input type="hidden" value="Tim">
						<input name="Tim" type="hidden" value="Tim">
						<button type="submit">&#43; Add to shop car</button>
					</div>
					</form>
				</div>
				<div class="products">
					<form action="Pharmacy.php" method="get">
					<img src="Pharamcy image/22.jpg"/>

					<p>
						ArtoVit & TensiVit
					</p>
					<div class="cmore">
						<input name="ArtoVit" type="hidden" value="ArtoVit">
					<button >&#43; Add to shop car</button>
					</div>
					</form>
				</div>
				<div class="products">
					<form action="Pharmacy.php" method="get">
					<img src="Pharamcy image/19.jpg"/>

					<p>
						LUMlUNS
					</p>
					<div class="cmore">
						<input name="LUMlUNS" type="hidden" value="LUMlUNS">
					<button type="submit">&#43; Add to shop car</button>
					</div>
					</form>
				</div>
				<div class="products">
					<form action="Pharmacy.php" method="get">
					<img src="Pharamcy image/7.jpg"/>

					<p>
						neoliva
					</p>
					<div class="cmore">
						<input name="neoliva" type="hidden" value="neoliva">
					<button name="neoliva">&#43; Add to shop car</button>
						</div>
					</form>
				</div>
				<div class="products">
					<form action="Pharmacy.php" method="get">
					<img src="Pharamcy image/8.jpg"/>

					<p>
						HAIR AID
					</p>
					<div class="cmore">
						<input name="HAIR_AID" type="hidden" value="HAIR_AID">
					<button name="HAIR_AID">&#43; Add to shop car</button>
					</div>
					</form>
				</div>
				<div class="products">
					<form action="Pharmacy.php" method="get">
					<img src="Pharamcy image/9.jpg"/>

					<p>
						Benosen
					</p>
					<div class="cmore">
						<input name="Benosen"type="hidden" value="Benosen">
					<button type="submit">&#43; Add to shop car</button>
					</div>
					</form>
				</div>
				<div class="products">
					<form action="Pharmacy.php" method="get">
					<img src="Pharamcy image/10.jpg"/>

					<p>
						Bbargava
					</p>
					<div class="cmore">
					<input name="Bbargava"type="hidden" value="Bbargava">
					<button >&#43; Add to shop car</button>
						
					</div>
					</form>
				</div>
				<div class="products">
					<form action="Pharmacy.php" method="get">
					<img src="Pharamcy image/11.jpg"/>

					<p>
						Blith Health
					</p>
					<div class="cmore">
					<input name="BlithHealth" type="hidden" value="BlithHealth">
					<button type="submit">&#43; Add to shop car</button>
					</div>
					</form>
				</div>
				<div class="products">
					<form action="Pharmacy.php" method="get">
					<img src="Pharamcy image/18.jpg"/>

					<p>
						Equalife+
					</p>
					<div class="cmore">
					<input  name="Equalife" type="hidden" value="Equalife">
					<button type="submit">&#43; Add to shop car</button>
					</div>
					</form>
				</div>
				<div class="products">
					<form action="Pharmacy.php" method="get">
					<img src="Pharamcy image/16.jpg"/>

					<p>
						DiureLine
					</p>
					<div class="cmore">
						<input  name="DiureLine" type="hidden" value="DiureLine">
					<button type="submit">&#43; Add to shop car</button>
					</div>
					</form>
				</div>
				<div class="products">
					<form action="Pharmacy.php" method="get">
					<img src="Pharamcy image/15.jpg"/>

					<p>
						Soranip
					</p>
					<div class="cmore">
						<input  name="Soranip" type="hidden" value="Soranip">
					<button type="submit">&#43; Add to shop car</button>
					</div>
					</form>
				</div>
				<h1>More products</h1>

				<div class="products">
					<form action="Pharmacy.php" method="get">
					<img src="Pharamcy image/25.jpg"/>

					<p>
           BIFORM
					</p>
					<div class="cmore">
					<input name="BIFORM" type="hidden" value="BIFORM">
					<button >&#43; Add to shop car</button>
					</div>
					</form>
				</div>
				<div class="products">
					<form action="Pharmacy.php" method="get">
					<img src="Pharamcy image/26.jpg"/>

					<p>
						Antibiotics
					</p>
					<div class="cmore">
						<input  name="Antibiotics" type="hidden" value="Antibiotics">
					<button >&#43; Add to shop car</button>
					</div>
					</form>
				</div>
				<div class="products">
					<form action="Pharmacy.php" method="get">
					<img src="Pharamcy image/27.jpg"/>

					<p>
						TylEnon
					</p>
					<div class="cmore">
						<input  name="Antibiotics" type="hidden" value="Antibiotics">
					<button type="submit">&#43; Add to shop car</button>
					</div>
					</form>
				</div>
				<div class="products">
					<form action="Pharmacy.php" method="get">
					<img src="Pharamcy image/13.jpg"/>

					<p>
						FIVE Phos
					</p>
					<div class="cmore">	
						<input  name="FIVEPhos" type="hidden" value="FIVEPhos">
					<button type="submit" >&#43; Add to shop car</button>
					</div>
					</form>
				</div>
				<div class="products">
					<form action="Pharmacy.php" method="get">
					<img src="Pharamcy image/28.jpg"/>

					<p>
						Cafea Verda
					</p>
					<div class="cmore">
						<input  name="CafeaVerda" type="hidden" value="CafeaVerda">
					<button type="submit" >&#43; Add to shop car</button>
					</div>
					</form >
				</div>
				<div class="products">
					<form action="Pharmacy.php" method="get">
					<img src="Pharamcy image/29.jpg"/>

					<p>
						Odeprozale Capsules
					</p>
					<div class="cmore">
					<input  name="OdeprozaleCapsules" type="hidden" value="OdeprozaleCapsules">
					<button>&#43; Add to shop car</button>
					</div>
					</form>
				</div>
				<div class="products">
					<form action="Pharmacy.php" method="get">
					<img src="Pharamcy image/30.jpg"/>

					<p>
						100% ESSTEM
					</p>
					<div class="cmore">
					<input  name="ESSTEM"type="hidden" value="ESSTEM">
					<button >&#43; Add to shop car</button>
					</div>
					</form>
				</div>
					
				
			<div id="footer">
					
                
			</div>
				
		</div>
			
		</div>
		<script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/jq.js"></script>
	</body>
</html>
